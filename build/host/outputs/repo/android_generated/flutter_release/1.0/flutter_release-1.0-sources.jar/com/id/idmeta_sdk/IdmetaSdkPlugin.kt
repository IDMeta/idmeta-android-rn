// File: /.android/flutter/src/main/kotlin/com/id/idmeta_sdk/IdmetaSdkPlugin.kt

package com.id.idmeta_sdk

import android.app.Activity
import android.content.Intent
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import com.id.idmeta_sdk.camera.controller.CameraControllerActivity
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.embedding.engine.plugins.activity.ActivityAware
import io.flutter.embedding.engine.plugins.activity.ActivityPluginBinding
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import io.flutter.plugin.common.MethodChannel.Result
import net.idrnd.android.idlive.face.iad.camera.controller.IadOptions
import net.idrnd.face.iad.capture.License
import net.idrnd.face.iad.capture.LicenseException
import net.idrnd.face.iad.capture.LicenseType

class IdmetaSdkPlugin : FlutterPlugin, ActivityAware, MethodChannel.MethodCallHandler {

    private lateinit var channel: MethodChannel
    private var activity: Activity? = null
    private var pendingResult: Result? = null
    private var livenessActivityLauncher: ActivityResultLauncher<Intent>? = null

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        channel = MethodChannel(binding.binaryMessenger, "net.idrnd.iad/liveness")
        channel.setMethodCallHandler(this)
    }

    override fun onMethodCall(call: MethodCall, result: Result) {
        this.pendingResult = result
        when (call.method) {
            "init" -> handleInit(call, result)
            "startLiveness" -> handleStartLiveness(call, result)
            else -> result.notImplemented()
        }
    }

    private fun handleInit(call: MethodCall, result: Result) {
        try {
            val license = call.argument<String>("license")
            if (license == null) {
                result.error("MISSING_ARGUMENT", "License key is missing.", null)
                return
            }
            License.setLicense(license, LicenseType.FaceDetector)
            result.success(true)
        } catch (e: LicenseException) {
            result.error("LICENSE_ERROR", "Failed to set license: ${e.message}", null)
        }
    }

    private fun handleStartLiveness(call: MethodCall, result: Result) {
        val currentActivity = activity
        if (currentActivity == null) {
            result.error("NO_ACTIVITY", "Plugin is not attached to an activity.", null)
            return
        }

        val authToken = call.argument<String>("authToken")
        val templateId = call.argument<String>("templateId")
        val verificationId = call.argument<String>("verificationId")

        // Get payloadSize from Flutter, default to Normal if not provided.
        val payloadSizeString = call.argument<String>("payloadSize") ?: "Normal"
        val payloadSize = if (payloadSizeString == "Small") IadOptions.PayloadSize.Small else IadOptions.PayloadSize.Normal

        if (authToken == null || templateId == null || verificationId == null) {
            result.error("MISSING_ARGUMENTS", "AuthToken, TemplateId, or VerificationId is missing.", null)
            return
        }

        val intent = Intent(currentActivity, CameraControllerActivity::class.java).apply {
            putExtra("AUTH_TOKEN", authToken)
            putExtra("TEMPLATE_ID", templateId)
            putExtra("VERIFICATION_ID", verificationId)
            putExtra("PAYLOAD_SIZE", payloadSize) // Pass the payload size to the activity
        }
        livenessActivityLauncher?.launch(intent)
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        channel.setMethodCallHandler(null)
    }

    override fun onAttachedToActivity(binding: ActivityPluginBinding) {
        activity = binding.activity
        livenessActivityLauncher = (activity as androidx.activity.ComponentActivity).registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val data = result.data
                val iadResult = data?.getStringExtra("iadResult")
                val errorMessage = data?.getStringExtra("errorMessage")

                if (iadResult != null) {
                    pendingResult?.success(iadResult)
                } else if (errorMessage != null) {
                    pendingResult?.error("LIVENESS_FAILED", errorMessage, null)
                } else {
                    pendingResult?.error("UNKNOWN_ERROR", "An unknown error occurred.", null)
                }
            } else {
                pendingResult?.error("CANCELED", "Liveness check was canceled by the user.", null)
            }
            pendingResult = null
        }
    }

    override fun onDetachedFromActivity() {
        activity = null
        livenessActivityLauncher = null
    }

    override fun onReattachedToActivityForConfigChanges(binding: ActivityPluginBinding) {
        onAttachedToActivity(binding)
    }

    override fun onDetachedFromActivityForConfigChanges() {
        onDetachedFromActivity()
    }
}