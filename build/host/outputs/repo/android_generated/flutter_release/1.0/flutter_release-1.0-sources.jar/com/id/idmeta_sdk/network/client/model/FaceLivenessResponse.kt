package com.id.idmeta_sdk.network.client.model

data class FaceLivenessResponse(
    val score: Float?,
    val quality: Float?,
    val probability: Float?,
    val digitalManipulationCheck: DigitalManipulationCheck?
)
