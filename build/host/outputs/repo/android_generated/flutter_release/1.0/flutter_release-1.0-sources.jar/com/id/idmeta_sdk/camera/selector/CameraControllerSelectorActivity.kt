// File: CameraControllerSelectorActivity.kt

package com.id.idmeta_sdk.camera.selector

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial
import net.idrnd.android.idlive.face.iad.camera.controller.IadOptions
import com.id.idmeta_sdk.R
import com.id.idmeta_sdk.camera.controller.CameraControllerActivity
import com.id.idmeta_sdk.camera.controller.NoUiCameraControllerActivity

class CameraControllerSelectorActivity : AppCompatActivity(R.layout.camera_controller_selector_activity) {

    private lateinit var usePreviewSwitch: SwitchMaterial
    private lateinit var payloadSizeSwitch: SwitchMaterial

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Get references to the switches
        usePreviewSwitch = findViewById(R.id.usePreviewSwitch)
        payloadSizeSwitch = findViewById(R.id.payloadSizeSwitch)

        findViewById<Button>(R.id.openCameraScreenButton).setOnClickListener {
            startActivity(createIntent())
        }
    }

    private fun createIntent(): Intent {
        // 1. Determine which activity to launch based on the preview switch.
        val usePreview = usePreviewSwitch.isChecked
        val intent = if (usePreview) {
            Intent(this, CameraControllerActivity::class.java)
        } else {
            Intent(this, NoUiCameraControllerActivity::class.java)
        }

        // 2. Determine the payload size based on its switch.
        val payloadSize = if (payloadSizeSwitch.isChecked) {
            IadOptions.PayloadSize.Small
        } else {
            IadOptions.PayloadSize.Normal
        }

        // 3. Put the chosen payload size into the Intent's "extras".
        // This is how we pass data between activities.
        intent.putExtra("PAYLOAD_SIZE", payloadSize)
        
        // 4. For testing, we add dummy data here. In the real app, this
        // data comes from the IdmetaSdkPlugin.
        intent.putExtra("AUTH_TOKEN", "test_auth_token_from_selector")
        intent.putExtra("TEMPLATE_ID", "test_template_id_from_selector")
        intent.putExtra("VERIFICATION_ID", "test_verification_id_from_selector")

        return intent
    }
}