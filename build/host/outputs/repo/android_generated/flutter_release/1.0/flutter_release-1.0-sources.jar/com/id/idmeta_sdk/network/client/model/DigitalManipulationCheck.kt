package com.id.idmeta_sdk.network.client.model

data class DigitalManipulationCheck(
    val score: Float?,
    val probability: Float?
)
