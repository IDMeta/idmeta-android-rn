package com.id.idmeta_sdk.camera.controller

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.id.idmeta_sdk.R
import net.idrnd.android.idlive.face.iad.camera.controller.IadOptions

class CameraControllerActivity : AppCompatActivity(R.layout.camera_controller_activity) {
    private lateinit var startButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var faceRecognitionHintView: TextView

    // --- THIS IS THE FIX ---
    // We create the ViewModel by passing all the required data from the Intent into our Factory.
    private val viewModel: CameraControllerViewModel by viewModels {
        val intent = intent // Get the intent that started this activity
        val authToken = intent.getStringExtra("AUTH_TOKEN")
        val templateId = intent.getStringExtra("TEMPLATE_ID")
        val verificationId = intent.getStringExtra("VERIFICATION_ID")

        // Retrieve the payloadSize from the intent, defaulting to Normal if it's not provided.
        val payloadSize = intent.getSerializableExtra("PAYLOAD_SIZE") as? IadOptions.PayloadSize
            ?: IadOptions.PayloadSize.Normal

        // Basic validation
        if (authToken == null || templateId == null || verificationId == null) {
            Log.e("CameraController", "FATAL: Auth token or IDs are missing from the intent.")
            // In a real app, you might finish with an error result here.
            // For now, we'll proceed with empty strings to avoid a crash, but the API call will fail.
        }
        
        // Pass all the required parameters, including payloadSize.
        CameraControllerViewModel.CameraControllerViewModelFactory(
            authToken ?: "",
            templateId ?: "",
            verificationId ?: "",
            payloadSize
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // ... (rest of the file is exactly the same as before) ...
        // It correctly uses the viewModel that was just created.
        lifecycle.addObserver(viewModel)

        startButton = findViewById(R.id.startButton)
        progressBar = findViewById(R.id.progressBar)
        faceRecognitionHintView = findViewById(R.id.faceRecognitionHintView)

        viewModel.uiState.observe(this) { uiState ->
            uiState ?: return@observe
            when (uiState) {
                UiState.Idle -> {
                    startButton.isVisible = true
                    progressBar.isVisible = false
                    faceRecognitionHintView.isVisible = false
                    faceRecognitionHintView.text = ""
                }
                UiState.FaceDetection -> {
                    startButton.isVisible = false
                    progressBar.isVisible = false
                    faceRecognitionHintView.isVisible = true
                }
                UiState.PhotoProcessing -> {
                    progressBar.isVisible = true
                    faceRecognitionHintView.isVisible = false
                    faceRecognitionHintView.text = ""
                }
            }
        }

        viewModel.faceDetectionHint.observe(this) { hint ->
            hint ?: return@observe
            faceRecognitionHintView.text = hint
        }

        viewModel.errorMessage.observe(this) { errorMessage ->
            errorMessage ?: return@observe
            showErrorMessage(errorMessage)
        }

        viewModel.createCameraController(
            applicationContext,
            this,
            findViewById(R.id.previewView)
        )

        startButton.setOnClickListener(viewModel.onStartButtonClickListener)

        viewModel.activityFinishData.observe(this) { intentWithResult ->
            setResult(RESULT_OK, intentWithResult)
            finish()
        }
    }

    private fun showErrorMessage(message: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.error_title)
            .setOnDismissListener { viewModel.uiState.value = UiState.Idle }
            .setMessage(message)
            .show()
    }

    private fun showIadResult(message: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.response_title)
            .setOnDismissListener { viewModel.uiState.value = UiState.Idle }
            .setMessage(message)
            .show()
    }
}