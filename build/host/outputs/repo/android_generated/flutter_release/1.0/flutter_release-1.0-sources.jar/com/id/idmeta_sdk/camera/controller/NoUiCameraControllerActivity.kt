// File: /.android/flutter/src/main/kotlin/com/id/idmeta_sdk/camera/controller/NoUiCameraControllerActivity.kt

package com.id.idmeta_sdk.camera.controller

import android.os.Bundle
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.id.idmeta_sdk.R
import net.idrnd.android.idlive.face.iad.camera.controller.IadOptions

class NoUiCameraControllerActivity : AppCompatActivity(R.layout.no_ui_activity) {
    private lateinit var startButton: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var faceRecognitionHintView: TextView

    private val viewModel: CameraControllerViewModel by viewModels {
        val authToken = intent.getStringExtra("AUTH_TOKEN") ?: ""
        val templateId = intent.getStringExtra("TEMPLATE_ID") ?: ""
        val verificationId = intent.getStringExtra("VERIFICATION_ID") ?: ""
        
        val payloadSize = intent.getSerializableExtra("PAYLOAD_SIZE") as? IadOptions.PayloadSize
            ?: IadOptions.PayloadSize.Normal

        CameraControllerViewModel.CameraControllerViewModelFactory(
            authToken,
            templateId,
            verificationId,
            payloadSize
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycle.addObserver(viewModel)

        startButton = findViewById(R.id.startButton)
        progressBar = findViewById(R.id.progressBar)
        faceRecognitionHintView = findViewById(R.id.faceRecognitionHintView)

        viewModel.uiState.observe(this) { uiState ->
            uiState ?: return@observe
            when (uiState) {
                UiState.Idle -> {
                    startButton.isVisible = true
                    progressBar.isVisible = false
                    faceRecognitionHintView.isVisible = false
                }
                UiState.FaceDetection -> {
                    startButton.isVisible = false
                    progressBar.isVisible = false
                    faceRecognitionHintView.isVisible = true
                }
                UiState.PhotoProcessing -> {
                    progressBar.isVisible = true
                    faceRecognitionHintView.isVisible = false
                }
            }
        }

        viewModel.faceDetectionHint.observe(this) { hint ->
            hint ?: return@observe
            faceRecognitionHintView.text = hint
        }

        viewModel.errorMessage.observe(this) { errorMessage ->
            errorMessage ?: return@observe
            showErrorMessage(errorMessage)
        }

        viewModel.createCameraController(applicationContext, this)

        startButton.setOnClickListener(viewModel.onStartButtonClickListener)

        viewModel.activityFinishData.observe(this) { intent ->
            setResult(RESULT_OK, intent)
            finish()
        }
    }

    private fun showErrorMessage(message: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.error_title)
            .setOnDismissListener { viewModel.uiState.value = UiState.Idle }
            .setMessage(message)
            .show()
    }
}