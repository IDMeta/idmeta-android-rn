// File: PermissionRequesterActivity.kt

package com.id.idmeta_sdk.permission

import android.Manifest.permission.CAMERA
import android.content.Intent
import android.content.pm.PackageManager.PERMISSION_GRANTED
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.id.idmeta_sdk.R
import com.id.idmeta_sdk.camera.selector.CameraControllerSelectorActivity

class PermissionRequesterActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // The license check is removed. The Flutter plugin handles this now.
        // If permission is already granted, just move to the next screen.
        if (isCameraPermissionGranted()) {
            launchCameraControllerSelectorActivity()
            return
        }

        // If permission is not granted, show the layout that has the request button.
        setContentView(R.layout.permissions_request_activity)

        findViewById<Button>(R.id.requestPermissionButton).setOnClickListener {
            ActivityCompat.requestPermissions(this, arrayOf(CAMERA), PERMISSION_CAMERA_REQUEST)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == PERMISSION_CAMERA_REQUEST && isCameraPermissionGranted()) {
            launchCameraControllerSelectorActivity()
        }
    }

    private fun isCameraPermissionGranted(): Boolean {
        return ContextCompat.checkSelfPermission(baseContext, CAMERA) == PERMISSION_GRANTED
    }

    private fun launchCameraControllerSelectorActivity() {
        val intent = Intent(this, CameraControllerSelectorActivity::class.java)
        startActivity(intent)
        finish()
    }

    companion object {
        private const val PERMISSION_CAMERA_REQUEST = 1
    }
}