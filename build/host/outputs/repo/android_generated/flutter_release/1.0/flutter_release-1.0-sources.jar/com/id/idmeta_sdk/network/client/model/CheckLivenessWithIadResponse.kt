package com.id.idmeta_sdk.network.client.model

data class CheckLivenessWithIadResponse(
    val faceLiveness: FaceLivenessResponse?,
    val captureLiveness: CaptureLivenessResponse
)
