package com.id.idmeta_sdk.utils

import kotlin.math.roundToInt

/**
 * Convert the float number to integer percentage, e.g. 0.564 -> 56, 0.715 -> 72.
 */
fun Float.toIntPercent(): Int {
    return (this * 100).roundToInt()
}
