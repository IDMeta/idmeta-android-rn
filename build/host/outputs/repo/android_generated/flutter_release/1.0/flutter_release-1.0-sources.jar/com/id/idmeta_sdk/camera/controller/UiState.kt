package com.id.idmeta_sdk.camera.controller

enum class UiState {
    Idle,
    FaceDetection,
    PhotoProcessing
}
